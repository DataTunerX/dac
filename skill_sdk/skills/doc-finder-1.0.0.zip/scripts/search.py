#!/usr/bin/env python3
"""Search a keyword in all *.md files under a directory (substring match)."""
from __future__ import annotations

import argparse
import json
import pathlib
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="Markdown full-text search.")
    parser.add_argument("--dir", required=True)
    parser.add_argument("--keyword", required=True)
    parser.add_argument("--ignore-case", action="store_true")
    args = parser.parse_args()

    root = pathlib.Path(args.dir).resolve()
    if not root.is_dir():
        print(f"not a directory: {root}", file=sys.stderr)
        return 1

    needle = args.keyword.lower() if args.ignore_case else args.keyword
    hits: list[dict] = []
    for path in sorted(root.rglob("*.md")):
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            continue
        for i, line in enumerate(text.splitlines(), start=1):
            haystack = line.lower() if args.ignore_case else line
            if needle in haystack:
                hits.append(
                    {
                        "file": str(path.relative_to(root)),
                        "line": i,
                        "text": line.strip(),
                    }
                )

    print(
        json.dumps(
            {"dir": str(root), "keyword": args.keyword, "count": len(hits), "hits": hits},
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())

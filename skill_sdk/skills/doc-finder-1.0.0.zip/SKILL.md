---
name: doc-finder
description: "Full-text search a keyword across the skill's bundled markdown reference docs (under references/). Use when the user asks to find / look up a term inside the bundled documentation."
---

# doc-finder

Search all `*.md` files under `<skill_dir>/references/` for a keyword
(substring match, optionally case-insensitive). Returns line-level hits.

Bundled docs:

- `references/architecture.md`
- `references/guidelines.md`
- `references/changelog.md`

## CLI

```bash
python3 "<skill_dir>/scripts/search.py" \
    --dir "<skill_dir>/references" \
    --keyword tenant \
    --ignore-case
```

Output JSON: `{dir, keyword, count, hits: [{file, line, text}, ...]}`.

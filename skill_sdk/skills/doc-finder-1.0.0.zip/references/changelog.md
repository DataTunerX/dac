# Changelog

## 2.1.0
- Added tenant-aware rate limiting.
- Fixed a bug where logs from different tenants could be mixed in the dashboard.

## 2.0.0
- Initial tenant-aware release: tenants table, tenant middleware, per-tenant keys.

## 1.4.0
- Introduced rate limiting (single-tenant).

# Engineering Guidelines

- All new endpoints must accept and propagate the tenant header.
- Never issue cross-tenant queries in dashboards; they break isolation.
- Prefer reading the caller's tenant from request context, not from URL params.

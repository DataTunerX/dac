# Architecture

The system uses a multi-tenant design where each tenant is isolated by `tenant_id`.
Events flow through Kafka and are persisted per tenant in the warehouse.

Every request carries a tenant header, resolved at the edge by the tenant middleware.

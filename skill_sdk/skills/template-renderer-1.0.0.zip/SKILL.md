---
name: template-renderer
description: "Render a text template from the bundled assets/ directory, substituting {{var}} placeholders with given key=value pairs. Use when the user asks to fill a template / scaffold text with variables."
---

# template-renderer

Render a `.tmpl` file from the bundled `assets/` directory. Placeholders
look like `{{name}}` and are replaced from `--vars KEY=VALUE,KEY=VALUE`.

Templates (under `<skill_dir>/assets/`):

- `greeting.tmpl`  — expects `name`, `product`, `date`.
- `invoice.tmpl`   — expects `number`, `customer`, `amount`, `date`.

## CLI

```bash
python3 "<skill_dir>/scripts/render.py" \
    --template greeting \
    --vars "name=Alice,product=Clawdbot,date=2026-05-01"

# list bundled templates
ls "<skill_dir>/assets/"
```

Output is a JSON line with `{template, templates_dir, vars_used, output}`.

#!/usr/bin/env python3
"""Render a bundled template with simple {{var}} substitutions."""
from __future__ import annotations

import argparse
import json
import pathlib
import re
import sys


def _parse_vars(blob: str) -> dict[str, str]:
    out: dict[str, str] = {}
    if not blob:
        return out
    for pair in blob.split(","):
        if not pair.strip():
            continue
        if "=" not in pair:
            raise ValueError(f"bad --vars entry: {pair!r}")
        k, v = pair.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description="Render a .tmpl file with {{var}} substitution.")
    parser.add_argument("--template", required=True, help="Template base name without .tmpl")
    parser.add_argument("--vars", default="", help="Comma list: KEY=VALUE,KEY=VALUE")
    parser.add_argument("--templates-dir", help="Override bundled assets/ directory")
    args = parser.parse_args()

    here = pathlib.Path(__file__).resolve().parent  # scripts/
    if args.templates_dir:
        tdir = pathlib.Path(args.templates_dir).resolve()
    else:
        tdir = (here.parent / "assets").resolve()

    tpath = tdir / f"{args.template}.tmpl"
    if not tpath.is_file():
        print(
            json.dumps(
                {
                    "error": "template not found",
                    "template": args.template,
                    "looked_at": str(tpath),
                    "available": sorted(p.name for p in tdir.glob("*.tmpl")) if tdir.is_dir() else [],
                },
                ensure_ascii=False,
            ),
            file=sys.stderr,
        )
        return 1

    try:
        vars_map = _parse_vars(args.vars)
    except ValueError as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2

    text = tpath.read_text(encoding="utf-8")
    rendered = re.sub(
        r"\{\{\s*(\w+)\s*\}\}",
        lambda m: vars_map.get(m.group(1), m.group(0)),
        text,
    )
    print(
        json.dumps(
            {
                "template": args.template,
                "templates_dir": str(tdir),
                "vars_used": vars_map,
                "output": rendered,
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())

---
name: config-reader
description: "Read the skill's bundled JSON config and return the value at a dotted key path (e.g. database.host). Use when the user asks to fetch a setting / field from the bundled configuration."
---

# config-reader

The bundled config lives at `<skill_dir>/assets/config.json`. Use
`scripts/query.py` to read a value at a dotted key path.

## CLI

```bash
python3 "<skill_dir>/scripts/query.py" \
    --file "<skill_dir>/assets/config.json" \
    --key database.host
```

Output: `{file, key, found, value}` (value omitted when `found` is `false`).

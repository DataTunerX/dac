#!/usr/bin/env python3
"""Read a JSON config and return the value at a dotted key path."""
from __future__ import annotations

import argparse
import json
import pathlib
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="JSON config reader.")
    parser.add_argument("--file", required=True)
    parser.add_argument("--key", required=True, help="Dotted key path, e.g. database.host")
    args = parser.parse_args()

    path = pathlib.Path(args.file)
    if not path.is_file():
        print(f"file not found: {path}", file=sys.stderr)
        return 1
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        print(f"parse error: {exc}", file=sys.stderr)
        return 2

    node = obj
    for part in args.key.split("."):
        if isinstance(node, dict) and part in node:
            node = node[part]
        else:
            print(
                json.dumps(
                    {"file": str(path), "key": args.key, "found": False},
                    ensure_ascii=False,
                )
            )
            return 3

    print(
        json.dumps(
            {"file": str(path), "key": args.key, "found": True, "value": node},
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())

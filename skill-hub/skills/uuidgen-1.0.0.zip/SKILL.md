---
name: uuidgen
description: "Generate one or more v4 UUIDs. Use when the user asks for a UUID, GUID, or unique identifier."
---

# uuidgen

Generate random v4 UUIDs.

## CLI

```bash
python3 uuidgen.py --count 3
python3 uuidgen.py --count 1 --upper
```

`--count` is capped at 1000. Output JSON: `{count, uuids}`.

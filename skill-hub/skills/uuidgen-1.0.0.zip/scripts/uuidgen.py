#!/usr/bin/env python3
"""Generate one or more v4 UUIDs."""
from __future__ import annotations

import argparse
import json
import sys
import uuid


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate v4 UUIDs.")
    parser.add_argument("--count", type=int, default=1, help="Number of UUIDs (default 1)")
    parser.add_argument("--upper", action="store_true", help="Uppercase hex")
    args = parser.parse_args()

    if args.count < 1 or args.count > 1000:
        print("count must be in [1, 1000]", file=sys.stderr)
        return 2

    ids = [str(uuid.uuid4()) for _ in range(args.count)]
    if args.upper:
        ids = [x.upper() for x in ids]
    print(json.dumps({"count": args.count, "uuids": ids}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Count words, lines, and characters in text or a file."""
from __future__ import annotations

import argparse
import json
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="Word / line / char counts.")
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument("--text", help="Inline UTF-8 text")
    src.add_argument("--file", help="Path to a UTF-8 text file")
    args = parser.parse_args()

    if args.text is not None:
        content = args.text
        source = "text"
    else:
        with open(args.file, "r", encoding="utf-8") as fh:
            content = fh.read()
        source = f"file:{args.file}"

    lines = content.splitlines()
    words = content.split()
    print(
        json.dumps(
            {
                "source": source,
                "chars": len(content),
                "words": len(words),
                "lines": len(lines),
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())

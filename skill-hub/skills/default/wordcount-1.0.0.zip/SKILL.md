---
name: wordcount
description: "Count words, lines, and characters in a piece of text or a text file. Use when the user asks for word count / line count / character count."
---

# wordcount

Count characters, words, and lines in a UTF-8 string or file.

## CLI

```bash
python3 wordcount.py --text "hello world"
python3 wordcount.py --file ./essay.txt
```

Output JSON: `{source, chars, words, lines}`.

---
name: base64tool
description: "Base64 encode or decode a UTF-8 text value (standard or URL-safe). Use when the user asks to base64-encode / decode something."
---

# base64tool

Base64 encode / decode a UTF-8 string.

## CLI

```bash
python3 base64tool.py encode --text "open sesame"
python3 base64tool.py decode --text "b3BlbiBzZXNhbWU="
python3 base64tool.py encode --text "a?b" --url-safe
```

Output JSON: `{mode, output}`.

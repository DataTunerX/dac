#!/usr/bin/env python3
"""Base64 encode / decode a UTF-8 string."""
from __future__ import annotations

import argparse
import base64
import json
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="Base64 encode / decode.")
    sub = parser.add_subparsers(dest="cmd", required=True)

    enc = sub.add_parser("encode", help="Encode UTF-8 text to base64")
    enc.add_argument("--text", required=True)
    enc.add_argument("--url-safe", action="store_true")

    dec = sub.add_parser("decode", help="Decode base64 to UTF-8 text")
    dec.add_argument("--text", required=True)
    dec.add_argument("--url-safe", action="store_true")

    args = parser.parse_args()
    if args.cmd == "encode":
        data = args.text.encode("utf-8")
        b = base64.urlsafe_b64encode(data) if args.url_safe else base64.b64encode(data)
        print(json.dumps({"mode": "encode", "output": b.decode("ascii")}, ensure_ascii=False))
        return 0

    b = args.text.encode("ascii")
    data = base64.urlsafe_b64decode(b) if args.url_safe else base64.b64decode(b)
    print(
        json.dumps(
            {"mode": "decode", "output": data.decode("utf-8", errors="replace")},
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())

---
name: timestamp
description: "Convert between unix epoch seconds and ISO-8601 datetime strings. Use when the user asks to convert a timestamp to / from a human readable time."
---

# timestamp

Convert between unix epoch seconds and ISO-8601 datetimes.

## CLI

```bash
# epoch -> human
python3 timestamp.py to-human 1700000000 --tz UTC
python3 timestamp.py to-human 1700000000 --tz local

# human -> epoch
python3 timestamp.py to-unix "2023-11-14T22:13:20+00:00"
```

Output JSON for `to-human`: `{unix, tz, iso, human}`.
Output JSON for `to-unix`:  `{iso, unix}`.

#!/usr/bin/env python3
"""Convert between unix epoch seconds and ISO-8601 datetime."""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone


def main() -> int:
    parser = argparse.ArgumentParser(description="Timestamp <-> human datetime.")
    sub = parser.add_subparsers(dest="cmd", required=True)

    to_h = sub.add_parser("to-human", help="Unix seconds -> ISO datetime")
    to_h.add_argument("unix", type=float)
    to_h.add_argument("--tz", default="UTC", help="'UTC' or 'local' (default UTC)")

    to_u = sub.add_parser("to-unix", help="ISO datetime -> Unix seconds")
    to_u.add_argument("iso")

    args = parser.parse_args()

    if args.cmd == "to-human":
        if args.tz == "local":
            dt = datetime.fromtimestamp(args.unix).astimezone()
        else:
            dt = datetime.fromtimestamp(args.unix, tz=timezone.utc)
        print(
            json.dumps(
                {
                    "unix": args.unix,
                    "tz": args.tz,
                    "iso": dt.isoformat(),
                    "human": dt.strftime("%Y-%m-%d %H:%M:%S %Z").strip(),
                },
                ensure_ascii=False,
            )
        )
        return 0

    dt = datetime.fromisoformat(args.iso)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    print(
        json.dumps(
            {
                "iso": args.iso,
                "unix": dt.timestamp(),
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())

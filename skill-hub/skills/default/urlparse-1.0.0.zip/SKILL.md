---
name: urlparse
description: "Parse a URL into scheme, userinfo, host, port, path, query, and fragment. Use when the user asks to decompose / inspect a URL."
---

# urlparse

Parse a URL into components using Python's `urllib.parse.urlparse`.

## CLI

```bash
python3 urlparse.py --url "https://user:pass@example.com:8080/a/b?x=1&y=2#frag"
```

Output JSON includes: `scheme, username, password, host, port, path,
params, query (as dict), fragment`.

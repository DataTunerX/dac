#!/usr/bin/env python3
"""Parse a URL into its components."""
from __future__ import annotations

import argparse
import json
import sys
from urllib.parse import parse_qsl, urlparse


def main() -> int:
    parser = argparse.ArgumentParser(description="Parse a URL.")
    parser.add_argument("--url", required=True)
    args = parser.parse_args()

    p = urlparse(args.url)
    print(
        json.dumps(
            {
                "scheme": p.scheme,
                "username": p.username,
                "password": p.password,
                "host": p.hostname,
                "port": p.port,
                "path": p.path,
                "params": p.params,
                "query": dict(parse_qsl(p.query, keep_blank_values=True)),
                "fragment": p.fragment,
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())

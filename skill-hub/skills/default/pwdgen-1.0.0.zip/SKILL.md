---
name: pwdgen
description: "Generate a random password of the requested length, optionally excluding symbols or digits. Use when the user asks to generate a password."
---

# pwdgen

Generate a cryptographically random password using `secrets`.

## CLI

```bash
python3 pwdgen.py --length 16
python3 pwdgen.py --length 24 --no-symbols
python3 pwdgen.py --length 12 --no-digits
```

`--length` must be in `[4, 256]`. Output JSON: `{length, password}`.

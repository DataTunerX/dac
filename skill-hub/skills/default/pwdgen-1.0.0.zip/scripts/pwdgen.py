#!/usr/bin/env python3
"""Generate a random password."""
from __future__ import annotations

import argparse
import json
import secrets
import string
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="Random password generator.")
    parser.add_argument("--length", type=int, default=16)
    parser.add_argument("--no-symbols", action="store_true")
    parser.add_argument("--no-digits", action="store_true")
    args = parser.parse_args()

    if args.length < 4 or args.length > 256:
        print("length must be in [4, 256]", file=sys.stderr)
        return 2

    alphabet = string.ascii_letters
    if not args.no_digits:
        alphabet += string.digits
    if not args.no_symbols:
        alphabet += "!@#$%^&*()-_=+[]{};:,.?"
    pwd = "".join(secrets.choice(alphabet) for _ in range(args.length))
    print(json.dumps({"length": args.length, "password": pwd}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())

---
name: jsonfmt
description: "Validate JSON and pretty-print it. Use when the user asks to check / lint / format / prettify a JSON string or file."
---

# jsonfmt

Validate and pretty-print JSON content.

## CLI

```bash
python3 jsonfmt.py --text '{"a":1,"b":[2,3]}' --indent 2
python3 jsonfmt.py --file ./data.json
```

- On success: prints `{"valid": true, "pretty": "<pretty-printed>"}`.
- On failure: prints `{"valid": false, "error": "...", "lineno": N, "colno": N}`
  and returns non-zero.

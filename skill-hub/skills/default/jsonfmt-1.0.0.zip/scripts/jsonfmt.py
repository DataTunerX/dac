#!/usr/bin/env python3
"""Validate and pretty-print JSON from inline text or a file."""
from __future__ import annotations

import argparse
import json
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate / pretty-print JSON.")
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument("--text", help="Inline JSON text")
    src.add_argument("--file", help="Path to a JSON file")
    parser.add_argument("--indent", type=int, default=2)
    args = parser.parse_args()

    raw = args.text if args.text is not None else open(args.file, "r", encoding="utf-8").read()
    try:
        obj = json.loads(raw)
    except json.JSONDecodeError as exc:
        print(
            json.dumps(
                {"valid": False, "error": str(exc), "lineno": exc.lineno, "colno": exc.colno},
                ensure_ascii=False,
            )
        )
        return 1

    pretty = json.dumps(obj, ensure_ascii=False, indent=args.indent, sort_keys=True)
    print(json.dumps({"valid": True, "pretty": pretty}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())

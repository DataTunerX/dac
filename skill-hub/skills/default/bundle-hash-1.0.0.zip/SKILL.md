---
name: bundle-hash
description: "Compute a combined sha256 checksum over all files in a directory, and optionally verify it against an expected value. Use when the user asks to hash / verify a bundle of files."
---

# bundle-hash

Two scripts:

- `scripts/checksum.py` — compute combined sha256 over a directory.
- `scripts/sub/verify.py` — verify a directory's combined sha256
  matches an expected value (invokes `checksum.py` internally).

A small sample dataset lives under `assets/` (three short text files).

## CLI

```bash
python3 "<skill_dir>/scripts/checksum.py" --dir "<skill_dir>/assets"
python3 "<skill_dir>/scripts/sub/verify.py" \
    --dir "<skill_dir>/assets" \
    --expected <hex-digest>
```

Output of `checksum.py`:
`{dir, sha256, count, total_bytes, files: [{rel, size}]}`.
Output of `verify.py`: `{expected, got, match, count}`.

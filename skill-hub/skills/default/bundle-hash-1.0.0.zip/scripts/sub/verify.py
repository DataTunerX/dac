#!/usr/bin/env python3
"""Verify that combining a directory's files produces the expected sha256."""
from __future__ import annotations

import argparse
import json
import pathlib
import subprocess
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify bundle checksum.")
    parser.add_argument("--dir", required=True)
    parser.add_argument("--expected", required=True)
    args = parser.parse_args()

    here = pathlib.Path(__file__).resolve().parent  # scripts/sub
    checksum_py = here.parent / "checksum.py"
    completed = subprocess.run(
        [sys.executable, str(checksum_py), "--dir", args.dir],
        capture_output=True,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        print(completed.stderr or completed.stdout, file=sys.stderr)
        return completed.returncode

    data = json.loads(completed.stdout)
    got = data["sha256"]
    match = got == args.expected
    print(
        json.dumps(
            {"expected": args.expected, "got": got, "match": match, "count": data["count"]},
            ensure_ascii=False,
        )
    )
    return 0 if match else 1


if __name__ == "__main__":
    sys.exit(main())

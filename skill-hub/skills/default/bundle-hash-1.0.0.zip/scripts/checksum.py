#!/usr/bin/env python3
"""Combined sha256 over every file in a directory (sorted by rel path)."""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="Bundle checksum.")
    parser.add_argument("--dir", required=True)
    args = parser.parse_args()

    root = pathlib.Path(args.dir).resolve()
    if not root.is_dir():
        print(f"not a directory: {root}", file=sys.stderr)
        return 1

    h = hashlib.sha256()
    files: list[dict] = []
    total = 0
    for path in sorted(root.rglob("*"), key=lambda p: str(p.relative_to(root))):
        if not path.is_file():
            continue
        rel = str(path.relative_to(root))
        data = path.read_bytes()
        h.update(rel.encode("utf-8"))
        h.update(b"\0")
        h.update(data)
        h.update(b"\0")
        files.append({"rel": rel, "size": len(data)})
        total += len(data)

    print(
        json.dumps(
            {
                "dir": str(root),
                "sha256": h.hexdigest(),
                "count": len(files),
                "total_bytes": total,
                "files": files,
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())

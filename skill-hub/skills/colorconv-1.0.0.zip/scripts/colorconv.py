#!/usr/bin/env python3
"""Convert between hex color and RGB tuple."""
from __future__ import annotations

import argparse
import json
import sys


def hex_to_rgb(h: str) -> tuple[int, int, int]:
    h = h.strip().lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    if len(h) != 6:
        raise ValueError(f"invalid hex color: {h!r}")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def rgb_to_hex(r: int, g: int, b: int) -> str:
    for name, value in (("r", r), ("g", g), ("b", b)):
        if not 0 <= value <= 255:
            raise ValueError(f"{name} out of range [0,255]: {value}")
    return "#{:02x}{:02x}{:02x}".format(r, g, b)


def main() -> int:
    parser = argparse.ArgumentParser(description="Color converter.")
    sub = parser.add_subparsers(dest="cmd", required=True)

    h2r = sub.add_parser("hex-to-rgb")
    h2r.add_argument("hex")

    r2h = sub.add_parser("rgb-to-hex")
    r2h.add_argument("r", type=int)
    r2h.add_argument("g", type=int)
    r2h.add_argument("b", type=int)

    args = parser.parse_args()
    if args.cmd == "hex-to-rgb":
        r, g, b = hex_to_rgb(args.hex)
        print(json.dumps({"hex": args.hex, "rgb": [r, g, b]}, ensure_ascii=False))
        return 0

    hx = rgb_to_hex(args.r, args.g, args.b)
    print(json.dumps({"rgb": [args.r, args.g, args.b], "hex": hx}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())

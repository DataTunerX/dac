---
name: colorconv
description: "Convert between hex color codes (e.g. #ff8800) and RGB tuples. Use when the user asks to translate a color between hex and RGB formats."
---

# colorconv

Convert between hex color notation and RGB.

## CLI

```bash
python3 colorconv.py hex-to-rgb "#ff8800"
python3 colorconv.py hex-to-rgb "f80"
python3 colorconv.py rgb-to-hex 255 136 0
```

Output JSON: `{hex, rgb}` or `{rgb, hex}`.

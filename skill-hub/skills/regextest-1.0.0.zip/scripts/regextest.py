#!/usr/bin/env python3
"""Test a regex pattern against a string."""
from __future__ import annotations

import argparse
import json
import re
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="Regex tester.")
    parser.add_argument("--pattern", required=True)
    parser.add_argument("--text", required=True)
    parser.add_argument("--flags", default="", help="Any of i,m,s,x")
    parser.add_argument("--all", action="store_true", help="Find all matches")
    args = parser.parse_args()

    flag_value = 0
    for ch in args.flags:
        flag_value |= {"i": re.I, "m": re.M, "s": re.S, "x": re.X}.get(ch, 0)
    try:
        pattern = re.compile(args.pattern, flag_value)
    except re.error as exc:
        print(json.dumps({"error": f"invalid regex: {exc}"}, ensure_ascii=False))
        return 1

    if args.all:
        result = [{"match": m.group(0), "groups": list(m.groups()), "span": list(m.span())} for m in pattern.finditer(args.text)]
        print(json.dumps({"matches": result, "count": len(result)}, ensure_ascii=False))
        return 0

    m = pattern.search(args.text)
    if not m:
        print(json.dumps({"matched": False}, ensure_ascii=False))
        return 0
    print(
        json.dumps(
            {
                "matched": True,
                "match": m.group(0),
                "groups": list(m.groups()),
                "span": list(m.span()),
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())

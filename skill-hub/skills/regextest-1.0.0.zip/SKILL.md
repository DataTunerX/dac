---
name: regextest
description: "Test a regular expression against a string and report matches / groups. Use when the user asks whether a regex matches some text, or to extract matches."
---

# regextest

Evaluate a regular expression against a string.

## CLI

```bash
# first match
python3 regextest.py --pattern "\\d{3}-\\d{4}" --text "call 555-1212 now"

# all matches + case-insensitive
python3 regextest.py --pattern "foo" --text "Foo and FOO" --flags i --all
```

Flags string chars: `i`, `m`, `s`, `x` (mapped to `re.I/M/S/X`).
Output JSON: for a single match `{matched, match, groups, span}`,
for `--all` `{matches: [...], count}`.

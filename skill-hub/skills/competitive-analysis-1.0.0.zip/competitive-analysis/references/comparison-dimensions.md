# Standard Comparison Dimensions

These are the default attributes to compare for an enterprise storage competitive analysis. Not every dimension applies to every workload: choose the subset relevant to what is actually being evaluated rather than mechanically filling every section.

## Mandatory requirements are not a dimension

Check hard requirements such as certifications, minimum capacity, mandatory protocols, and pass/fail RFP gates before comparing dimensions. Report a documented failure separately and exclude that option from later ranking. An unknown is unverified, not a pass or failure.

## Requirement-traceable compliance matrix

When an RFP or requirements document is available, use its requirement or clause numbers as the primary rows. Keep the proposed or incumbent product first, followed by competitors. Adopt the document's own status vocabulary when defined; otherwise use **Fully Compliant**, **Partially Compliant**, **Not Compliant**, and **Not Documented**. Preserve the customer's section structure.

Use the dimensions below for important workload concerns that the RFP does not cover.

## 1. Capacity & Efficiency

- Maximum raw, usable, and effective capacity per node, system, and scale limit
- Deduplication, compression, erasure coding, and RAID efficiency
- Guaranteed reduction ratios versus marketing “up to” ratios
- Minimum configuration and scaling increments

## 2. Performance

- IOPS, latency, throughput, and bandwidth with the stated test configuration
- Block size, read/write mix, protocol, queue depth, dataset, and latency ceiling
- Cache architecture, size, and tiering

## 3. Data Protection & Replication

- Synchronous replication and its RPO/RTO characteristics
- Asynchronous replication and distance or bandwidth constraints
- Snapshots, clones, immutability, and WORM
- Native ransomware or anomaly detection versus separate components

## 4. Protocol & Architecture Convergence

- FC, iSCSI, NVMe-oF variants, NFS, SMB, S3, HDFS, and other required protocols
- Whether block, file, and object share one platform and operating environment or require separate products

## 5. Availability & Resilience

- Published availability claim and whether it is an SLA, measured result, design target, or unqualified marketing claim
- Controller, node, enclosure, site, and other failure-domain tolerance
- Scope and limitations of non-disruptive upgrades and scale-out

## 6. Security & Compliance

- Encryption at rest and in flight, algorithms, and key management
- FIPS 140-2/3, Common Criteria, and relevant regional certifications
- Access control and multi-tenancy

## 7. Management & Automation

- Unified control plane across product lines versus separate consoles
- AIOps and predictive capabilities
- API and automation maturity

## 8. Commercial

Include only when reliable materials cover it:

- Perpetual, subscription, and consumption-based licensing
- Public list pricing or sourced TCO studies
- Do not estimate unpublished pricing; mark it not documented in reviewed materials

## Presentation pattern

For each selected dimension, build an attribute-rows × product-columns table. Follow it with a short workload-specific interpretation explaining which option is ahead on documented evidence, where products are equivalent, and where evidence gaps prevent a conclusion.

---
name: competitive-analysis
description: "Compare named enterprise storage products against workload or RFP requirements across capacity, performance, protection, protocols, resilience, security, management, and commercial dimensions. Requires identifiable products and evidence; distinguishes unsupported capabilities from facts that are merely not documented."
---

# Enterprise Storage Competitive Analysis

Produce an evidence-bounded, workload-relevant comparison of enterprise storage products.

## Required inputs

Identify the products or vendors, workload, and any mandatory requirements. If the user provides only vendor names, state which current product families are being compared or ask when selecting them would materially change the result. When an RFP or requirements document is supplied, preserve its clause numbers and terminology.

## Workflow

1. Read [references/comparison-dimensions.md](references/comparison-dimensions.md) and select only the dimensions that matter to the stated workload.
2. Evaluate mandatory requirements first. Report a documented hard failure separately and exclude that option from later ranking. Treat an unknown requirement as unverified, not passed or failed.
3. Gather evidence for every vendor using available TDB sources, vendor documentation, and authoritative current sources. Attach a source to each comparable fact. Never fill a missing value with an assumption.
4. Normalize before comparing numbers:
   - Performance requires comparable block size, read/write mix, protocol, queue depth, dataset, data-reduction state, and latency ceiling.
   - Capacity requires the same raw/usable/effective definition and equivalent protection level.
   - Compare current generally available releases and configurations that meet the same requirement.
   - If conditions differ or are unstated, show each claim with its conditions and mark the cross-vendor delta as not comparable.
5. For architecture claims such as active-active, global cache, end-to-end NVMe, scale-out, or non-disruptive upgrades, compare the mechanism and failure behavior rather than repeating the marketing label.
6. Use one requirement or attribute per row and one product per column. Use these findings consistently:
   - **Delivered**: documented as meeting the requirement.
   - **Partial / Conditional**: documented with a limitation, extra component, license, or configuration.
   - **Different mechanism**: achieves the outcome through a materially different design.
   - **Not supported**: a source explicitly says it is absent.
   - **Not documented**: reviewed sources did not establish it. Never rewrite this as unsupported.
7. Close with the workload-specific trade-off: what each option gives, what it costs, who it suits, and what missing fact or test would change the decision. Name the sources checked and material evidence gaps.

## Output

Lead with mandatory-requirement results when present. Then provide concise comparison tables for the selected dimensions and a decision-oriented trade-off paragraph. Do not manufacture a winner where products are equivalent or evidence is asymmetric.

For commercial or customer-facing use, explicitly flag claims that still require vendor confirmation.

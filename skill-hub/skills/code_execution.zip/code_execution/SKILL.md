---
name: code_execution
description: 需要由模型在受限 Python 沙箱中写代码、执行并自检来完成：数值/统计/聚合/清洗/小型数据处理。执行时**必须**调用 Runner 提供的 `code_exec` 工具（不要依赖本包内 shell 脚本作为主路径）。
---

## 能力边界

- **适用**：纯计算、对结构化数据（`list[dict]`、JSON 可还原结构）做汇总/筛选/派生列、对字符串做安全处理、在**无**文件 IO/无任意子进程的前提下可完成的逻辑。
- **不适用**：应优先用 `plan_cmd` 跑已有 CLI/仓库脚本/系统命令 的场景，或必须访问网络/写磁盘的任务。

## 与 `code_exec` 工具的固定约定

当本 skill 被选中后，在 **ReAct 工具列表里会出现名为 `code_exec` 的工具**（若运行环境已注入 `CodeExecution`）。你必须通过它完成计算，而不是只在对话里写伪代码。

### 参数

| 参数 | 含义 |
|------|------|
| `query` | 用自然语言写清楚：要得到什么、结果应放在沙箱的 `result` 里、期望类型（标量/列表/字典）。 |
| `context_data` | **字符串**。若用户或随附数据是 JSON，请传 **整段 JSON 文本**；若是普通文本则原样传入；无上下文则传 `""`（沙箱里 `data` 为 `None`）。 |
| `max_chars` | 可选。限制返回给对话上下文的 `result` 等字段长度，大结果会被截断。 |

### 推荐工作流

1. 若需读取本包内样例或用户提到的本地路径：先用 `read_file` 得到 `content`，再把**该 `content` 整段**作为 `context_data` 传给 `code_exec`（已是合法 JSON 时无需再加工）。
2. 调用 `code_exec`，检查返回 JSON 中 `conclusion`、`status`、`result`。
3. 用 `finish` 将 `result` 解释、排版后答复用户。

### 禁止

- 不要声称已执行 `code_exec` 却未在当轮产生对应的工具调用记录。
- 不要在本 skill 中把可一步完成的分析强行改成无意义的 `plan_cmd` 链；除非确需用命令行读环境信息。

## 样例数据

本包 `assets/sample_sales.json` 为销售记录样例。演示时可：`read_file` 读取该文件 → 将 `content` 作 `context_data` → 在 `query` 中要求按城市汇总金额等。

---
name: competitive-analysis
description: >
  Research and produce a vendor/product competitive analysis for enterprise storage — compares
  a proposed or incumbent product against named competitors across capacity, performance,
  replication/availability, protocol convergence, security, and management, citing every fact
  to its source and flagging anything unverified rather than guessing. Works for any vendor,
  including ones with no TDB coverage — searches TDB and the web to fill
  gaps. Use whenever the user wants a "competitive analysis," "battle card," "vendor comparison,"
  "positioning against competitors," "how does X stack up against Y," or is evaluating options
  for an RFP/RFI/HLD and needs to know how a solution compares to alternatives — even without
  the word "competitive" (e.g. "is Pure actually cheaper than NetApp for this workload").
metadata:
  version: "1.0"
---

# Enterprise Storage Competitive Analysis

## Why this skill exists

A competitive analysis is only useful if the reader can tell which claims are solid and which
are marketing. The whole point of this skill is discipline about sourcing, not cleverness about
storage — any storage vendor's public materials will make every product sound best-in-class, and
your job is to find what's actually documented, say plainly when something isn't, and never let a
gap in the research quietly become a gap in the customer's understanding of the tradeoffs.

## Step 1 — Scope the comparison

Before researching anything, pin down:

- **The proposed/incumbent product** (if there is one) and the **competitor(s)** to compare it
  against — the user may name specific models, or just vendors ("Dell vs NetApp"), or a use case
  without naming anyone ("what should we use for a Tier 0 OLTP refresh") in which case ask which
  vendors are actually in scope before researching blindly.
- **The workload/tier context** — mission-critical block, scale-out file/object, backup, AI/ML
  data lake, etc. This determines which dimensions in `references/comparison-dimensions.md`
  actually matter; don't run every dimension against every vendor regardless of relevance.
- **Output mode** — chat report or a standalone document. See `references/output-formats.md`.
  If ambiguous, ask; default to chat if you truly can't tell, since it's cheaper to upgrade a
  chat answer into a document afterward than the reverse.
- **Whether this analysis might end up external.** If there's any chance this comparison gets
  attached to a customer submission, published, or shown to the vendors being compared, say so
  now and hold every source to the stricter public/dated/retrievable bar in
  `references/source-authority.md` from the start — re-checking a comparison built for internal
  use only, right before it goes external, is where sourcing gaps get missed. Internal bid
  strategy and anything that could go external are not the same deliverable; don't silently
  reuse one as the other.
- **What the customer is actually focused on.** If there's an RFP, requirements doc, or even just
  a few sentences from the user about what matters most, read it for that before doing anything
  else — specifically, which requirements are stated as mandatory, which get repeated or dwelt on,
  and which functional areas the workload context makes load-bearing. This is the single biggest
  lever on how the rest of this skill runs: it's what decides whether a dimension gets a full
  table or a one-line equivalence note (Step 4), whether the primary table should be built from
  the RFP's own clause numbers instead of generic dimensions, whether an architecture diagram
  earns its space, whether any claim is pointed enough to need a source excerpt, and whether a
  "recommended requirement language" section belongs in the output at all (Step 5). Every
  optional element described below exists to serve a customer's actual focus, not to be produced
  by default — when in doubt about whether one is worth including, this is the thing to check
  against.

## Step 2 — Research each vendor/product, in priority order

Work through this order for **every** vendor in scope, including the proposed/incumbent one —
don't skip sourcing discipline for "your own" product just because it's the one being pitched.

1. **TDB** — route the vendor/product to the appropriate gateway in
   `references/tdb-gateways.md`. Check `/v2/health`, then use the documented ontology, wiki, and
   `/v2/search/query` APIs for structured facts and vendor-document passages. Check the gateway's
   domain/stream binding when needed and inspect `resolved_stream_ids` before accepting search
   hits. TDB coverage varies and is worth checking directly rather than assuming — some vendors
   that seem obvious competitors may simply not be ingested yet.
2. **Live web search** — only after TDB has been checked and come up short
   for a specific vendor or fact. This is expected to happen often for vendors nobody has loaded
   into TDB yet — that's exactly the case this step exists for. Search for the vendor's own current
   datasheet/spec page first, not third-party summaries.

Label every fact per `references/source-authority.md` and record the gateway/database metadata
from `references/tdb-gateways.md` as you go — don't defer sourcing to the
end, since it's much easier to lose track of where a number came from after the fact than to
label it the moment you find it.

Apply the same evidence bar to the proposed/incumbent product as to every competitor. If you
notice you have visibly deeper or higher-tier evidence for one vendor than another on the same
point, that's an asymmetry worth flagging in the write-up (e.g. "X's figure comes from richer TDB
evidence; Y's is the only public datasheet we could find") rather than letting the richer-looking
entry read as more capable by accident of research depth.

For workloads where controller architecture, cache design, or backend/media architecture is
actually load-bearing to the comparison, skim `references/architecture-differentiators.md` for
named patterns worth investigating specifically (e.g. symmetric active-active vs. ALUA, global
vs. HA-pair cache) — these catch marketing claims that sound equivalent but describe materially
different mechanisms. Load it on demand, not for every comparison; most dimension-level research
in Step 2 won't need it.

## Step 3 — Check mandatory requirements first, if any exist

If the user has stated hard requirements — a certification, a minimum capacity, a required
protocol, a pass/fail evaluation gate from an RFP — check every vendor against those *before*
building comparison tables for anything else. A vendor that fails a stated mandatory requirement
is excluded from the ranked comparison and reported separately with the requirement it failed;
don't let a strong showing on unrelated dimensions soften a hard failure into a middling score.
If a mandatory requirement's status is genuinely unknown (not failed, just unverified), say so
and keep the vendor provisionally in scope pending that confirmation — an unknown is not a pass.

Skip this step cleanly (don't force it) when the user hasn't stated any hard requirements — most
open-ended "how does X compare to Y" questions won't have any, and that's fine.

## Step 4 — Build the comparison

**If the user has an actual RFP or requirements document**, build the primary table from its own
requirement/clause numbers, not from the generic dimension list — see
`references/comparison-dimensions.md`'s "Requirement-traceable compliance matrix" section for the
row/status format. This is more useful to the reader than a generic-dimension table because it
lets them find "does this meet clause 3.1.7" directly, and it's what the customer's own
evaluation will actually check against. Use the generic dimensions from
`references/comparison-dimensions.md` to fill in anything the RFP doesn't cover, or as the whole
basis for the comparison when there's no RFP to trace against.

Otherwise, use `references/comparison-dimensions.md` to pick the dimensions that matter for this
workload, and build one table per dimension (or per tier, if multiple product categories are in
scope) — attribute rows, vendor columns, proposed/incumbent product as the first column.

For each cell, use one of these statuses rather than free-form prose, borrowed from
`references/source-authority.md`'s discipline of never overstating what was found:

- **Delivered** — documented as meeting the point being compared, with the source cited.
- **Partial / Conditional** — delivered, but with a real limitation, narrower scope, or an extra
  license/hardware/service requirement — state which.
- **Different mechanism** — the outcome is achieved a materially different way; describe the
  mechanism rather than just asserting equivalence.
- **Not supported** — a source explicitly states the capability is absent. Cite the statement.
- **Not documented** — nothing was found for this vendor at any research tier. This is never the
  same finding as "not supported" and must never be worded as if it were — the vendor may simply
  not publish that figure, or nobody's loaded their materials into TDB yet. Write it plainly
  (e.g. "not published in reviewed materials"), never left blank and never inferred.

Before stating any cross-vendor numeric difference, check it against
`references/normalization-rules.md` — most "differences" in vendor-published numbers turn out to
be different test conditions, different counting methodologies, or different product
generations, not real differences. An unnormalized numeric comparison is a false claim even if
every individual number is accurate.

After each table (or group of tables for one tier/category), write a short trade-off paragraph
rather than a plain summary — this is the part that requires judgment; the table is just the data
behind it:

1. **The choice**, stated neutrally as something the reader decides, not a conclusion.
2. **What each option gives**, specific and evidenced.
3. **What each option costs** — every real option costs something (capability given up,
   complexity, price, lock-in); if one side of the comparison looks costless, the analysis is
   incomplete, not the product.
4. **Who it suits** — the circumstances under which each choice is the right one.
5. **What would change the answer** — the specific fact or test result that would flip it. This
   is usually the single most useful sentence in the paragraph.

Where vendors are genuinely equivalent on a dimension or a specific architecture-differentiator
pattern, say that plainly instead of manufacturing a difference — a comparison that finds a
winner on every single dimension is advocacy, not research. Equivalence is also a signal about
how much space that point deserves in the output: give it a single compressed line ("both
vendors support X with no material difference found") rather than a full table-plus-trade-off
treatment, and put the space you saved toward the dimensions and patterns that actually
differentiate. The reader's attention is a resource too — don't spend it on ground that isn't
contested.

## Step 5 — Produce the output

Follow `references/output-formats.md` for the mode chosen in Step 1. Both modes end with a
closing caveat naming exactly which sources were checked and where they came up short — this is
not boilerplate, it's the reader's guide to how much independent confirmation they still need
before relying on any given figure commercially.

## A note on using this alongside other skills

This skill is currently standalone — it doesn't assume it's being called from anywhere else, and
you can invoke it directly for a one-off comparison with no other document in play. If you're
also working on an HLD, RFI response, or similar deliverable that needs a competitive-positioning
section, run this skill's methodology for that section and paste the result in, rather than
duplicating the research logic inline — the sourcing discipline here is the same either way.

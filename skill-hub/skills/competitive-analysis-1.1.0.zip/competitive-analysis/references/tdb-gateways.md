# TDB Gateway Access

Use TDB through the HTTP gateway APIs below. Do not connect directly to a database and do not
invent a connection string. Select the gateway from the vendor/product being researched, then
record the gateway URL and database in the evidence trail.

## Gateway routing

| Knowledge base | Gateway URL | Database |
|---|---|---|
| Huawei combined — all Huawei information | `http://10.124.48.91:8999` | `tdb_huawei_a` |
| Huawei Dorado | `http://10.124.48.91:9000` | `tdb_huawei_dorado` |
| Huawei Pacific | `http://10.124.48.91:9001` | `tdb_huawei_pacific` |
| Huawei OceanProtect | `http://10.124.48.91:9002` | `tdb_huawei_oceanprotect` |
| Huawei OceanDisk | `http://10.124.48.91:9003` | `tdb_huawei_oceandisk` |
| Huawei DCS | `http://10.124.48.91:9004` | `tdb_huawei_dcs` |
| Dell | `http://10.124.48.91:9005` | `tdb_dell` |
| NetApp | `http://10.124.48.91:9006` | `tdb_netapp` |
| IBM | `http://10.124.48.91:9007` | `tdb_ibm` |
| Everpure | `http://10.124.48.91:9008` | `tdb_everpure` |
| HPE | `http://10.124.48.91:9009` | `tdb_hpe` |
| Hitachi | `http://10.124.48.91:9010` | `tdb_hitachi` |
| Combined vendor knowledge | `http://10.124.48.91:9011` | `tdb_hld` |

For Huawei research, either use the Huawei combined gateway at port `8999` (`tdb_huawei_a`),
which contains all Huawei information, or use the product-specific gateway when the product
family is known and a split knowledge base is useful. For cross-vendor comparisons, either use
combined vendor knowledge (`tdb_hld`) or query the relevant vendor-specific TDBs separately and
combine the evidence during analysis.

## Query sequence

1. Check gateway health:
   `GET <gateway>/v2/health` (fall back to `GET <gateway>/health`).
2. Check the gateway's available domain/stream binding when needed:
   `GET <gateway>/v2/search/domain-stream/list?domain=<domain>`.
3. Search structured concepts:
   `GET <gateway>/v2/ontology/concept/search?domain=<domain>&q=<term>&limit=20`.
4. Retrieve explicit facts and relations:
   `GET <gateway>/v2/ontology/statement/list?subject_id=<subject_id>&limit=50`.
5. Search vendor-document passages:
   `POST <gateway>/v2/search/query` with a JSON body containing the query, the selected
   `domain`, and an appropriate search mode such as `lexical` when exact terms are needed.
6. Search or fetch relevant wiki material when exposed by the gateway:
   `GET <gateway>/v2/wiki/search?domain=<domain>&q=<term>` and
   `GET <gateway>/v2/wiki/page?domain=<domain>&slug=<slug>`.

Use URL encoding for query terms and slugs. Inspect `resolved_stream_ids` in search responses.
An empty list with non-empty hits indicates an unscoped query; do not use those hits as evidence
until the domain binding is corrected. A non-empty list with zero hits indicates a valid scope
with no match, so retry with shorter product names, model names, protocol terms, or `mode:
"lexical"`.

## Evidence record

For every TDB fact used in the comparison, retain:

- knowledge-base label
- gateway URL
- database identifier
- API endpoint and query term
- returned stream, concept, statement, page, or chunk identifier when available
- any configuration, license, version, or test-condition qualifiers

The database identifier identifies the configured TDB backend; it is not a credential or a
direct-connect target.

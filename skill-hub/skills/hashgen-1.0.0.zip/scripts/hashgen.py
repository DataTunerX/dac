#!/usr/bin/env python3
"""Compute md5/sha1/sha256 hash of a string or a file."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="Compute cryptographic hash.")
    parser.add_argument("--algo", default="sha256", choices=["md5", "sha1", "sha256"])
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument("--text", help="Inline UTF-8 text to hash")
    src.add_argument("--file", help="Path to a file to hash")
    args = parser.parse_args()

    if args.text is not None:
        data = args.text.encode("utf-8")
        source = "text"
    else:
        with open(args.file, "rb") as fh:
            data = fh.read()
        source = f"file:{args.file}"

    digest = hashlib.new(args.algo)
    digest.update(data)
    print(
        json.dumps(
            {
                "algo": args.algo,
                "source": source,
                "input_len": len(data),
                "hex": digest.hexdigest(),
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())

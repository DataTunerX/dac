---
name: hashgen
description: "Compute md5/sha1/sha256 cryptographic hash of a string or a file. Use when the user asks for a checksum, digest, or hash of some input."
---

# hashgen

Compute a cryptographic hash digest of either an inline string or a file.

## CLI

```bash
python3 hashgen.py --text "hello" --algo sha256
python3 hashgen.py --file /path/to/blob.bin --algo md5
```

Supported `--algo`: `md5`, `sha1`, `sha256` (default `sha256`).

Output: a single JSON line with `algo`, `source`, `input_len`, `hex`.
